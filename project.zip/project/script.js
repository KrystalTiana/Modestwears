function Validate()
{
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var number = document.getElementById("number").value;
    var message = document.getElementById("message").value;

    if(name == "John Doe" && email == "johndoe@yahoo.com" && number == "01388942345" && message == "I want to order for modest wears")
    {
        alert("Your Service was Scheduled Successfully");
        return false;
    }
    else{
        alert("Login Failed");
    }
}